package com.chuluhealth.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.content.*;
import android.database.Cursor;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    DB db; LinearLayout root, body; String user, role;
    int green=Color.rgb(8,127,91);

    public void onCreate(Bundle b){super.onCreate(b);db=new DB(this);showLogin();}

    TextView tv(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setPadding(12,10,12,10);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);return b;}
    EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setPadding(12,8,12,8);return e;}
    void base(String title){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        TextView h=tv("CHULU HEALTH\n"+title,21);h.setTextColor(Color.WHITE);h.setBackgroundColor(green);
        root.addView(h,new LinearLayout.LayoutParams(-1,-2));
        body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(14,12,14,20);
        ScrollView sv=new ScrollView(this);sv.addView(body);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
    }
    void showLogin(){
        base("Secure Login");
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        body.addView(tv("Integrated Health Facility System",18));
        EditText u=input("Username"); EditText p=input("Password");p.setInputType(0x81);
        body.addView(u);body.addView(p);
        Button b=btn("SIGN IN");body.addView(b);
        TextView info=tv("Demo password: CHULU-DEMO\nProduction deployment must use secure server authentication.",12);body.addView(info);
        b.setOnClickListener(v->{String r=db.login(u.getText().toString(),p.getText().toString());if(r==null){Toast.makeText(this,"Invalid login",Toast.LENGTH_SHORT).show();return;}user=u.getText().toString().toLowerCase();role=r;db.audit(user,role,"LOGIN","Successful login");dashboard();});
    }
    void dashboard(){
        base("Dashboard • "+role);
        body.addView(tv("Logged in as: "+user,14));
        String[] menu;
        switch(role){
            case "Doctor":menu=new String[]{"Register Patient","Client Assessment","Order Lab Tests","Prescription","Referral","Logout"};break;
            case "Lab":menu=new String[]{"Lab Queue","Upload Results","Logout"};break;
            case "Accountant":menu=new String[]{"Pricing & Authorisation","Receipts","Logout"};break;
            case "Pharmacy":menu=new String[]{"Dispensing","Bin Card / Stock","Logout"};break;
            case "HTS":menu=new String[]{"HTS Testing","Logout"};break;
            case "Data Clerk":menu=new String[]{"Reports / Export","Audit Trail","Logout"};break;
            default:menu=new String[]{"Accounts & Pharmacy Tally","Audit Trail","Logout"};
        }
        for(String s:menu){Button b=btn(s);body.addView(b);b.setOnClickListener(v->route(s));}
        body.addView(tv("Financial year: "+db.fy()+"-04-01 to "+(Integer.parseInt(db.fy())+1)+"-03-31",12));
    }
    void route(String s){
        if(s.equals("Logout")){db.audit(user,role,"LOGOUT","");showLogin();return;}
        if(s.equals("Register Patient"))registerPatient();
        else if(s.equals("Client Assessment"))simpleAssessment();
        else if(s.equals("Order Lab Tests"))orderLab();
        else if(s.equals("Prescription"))prescription();
        else if(s.equals("Referral"))referral();
        else if(s.equals("Lab Queue")||s.equals("Upload Results"))lab();
        else if(s.equals("Pricing & Authorisation"))accountant();
        else if(s.equals("Receipts"))receipt();
        else if(s.equals("Dispensing"))dispense();
        else if(s.equals("Bin Card / Stock"))stock();
        else if(s.equals("HTS Testing"))hts();
        else if(s.equals("Reports / Export"))reports();
        else if(s.equals("Audit Trail")||s.equals("Accounts & Pharmacy Tally"))auditOrTally(s);
    }
    void back(){dashboard();}
    void registerPatient(){
        base("Patient Registration");
        EditText n=input("Full name"), dob=input("Date of birth (YYYY-MM-DD)"), sex=input("Sex"), phone=input("Phone"), addr=input("Address");
        body.addView(n);body.addView(dob);body.addView(sex);body.addView(phone);body.addView(addr);
        Button save=btn("REGISTER PATIENT");body.addView(save);
        TextView id=tv("Patient ID will be generated automatically using the current financial year.",13);body.addView(id);
        save.setOnClickListener(v->{String pid=db.patientId();db.getWritableDatabase().execSQL("INSERT INTO patients VALUES(?,?,?,?,?,?,?)",new Object[]{pid,n.getText(),dob.getText(),sex.getText(),phone.getText(),addr.getText(),DB.now()});db.audit(user,role,"PATIENT_REGISTERED",pid+" "+n.getText());id.setText("REGISTERED: "+pid);Toast.makeText(this,"Patient registered",Toast.LENGTH_SHORT).show();});
    }
    String patients(){
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name FROM patients ORDER BY id DESC",null);StringBuilder s=new StringBuilder();
        while(c.moveToNext())s.append(c.getString(0)).append(" — ").append(c.getString(1)).append("\n");c.close();return s.toString();
    }
    void patientPick(Spinner sp){
        ArrayList<String> a=new ArrayList<>();Cursor c=db.getReadableDatabase().rawQuery("SELECT id||' — '||name FROM patients ORDER BY id DESC",null);while(c.moveToNext())a.add(c.getString(0));c.close();
        sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,a));
    }
    String pid(Spinner s){String x=(String)s.getSelectedItem();return x==null?"":x.split(" — ")[0];}
    void simpleAssessment(){
        base("Clinical Assessment");Spinner sp=new Spinner(this);patientPick(sp);body.addView(sp);
        EditText subj=input("Subjective / complaints");EditText obj=input("Objective / examination");EditText diag=input("Diagnosis");
        body.addView(subj);body.addView(obj);body.addView(diag);Button b=btn("SAVE ASSESSMENT");body.addView(b);
        b.setOnClickListener(v->{db.getWritableDatabase().execSQL("UPDATE patients SET date_registered=date_registered WHERE id=?",new Object[]{pid(sp)});db.audit(user,role,"ASSESSMENT",pid(sp)+" diagnosis="+diag.getText());Toast.makeText(this,"Assessment saved",Toast.LENGTH_SHORT).show();});
    }
    void orderLab(){
        base("Order Laboratory Tests");Spinner sp=new Spinner(this);patientPick(sp);body.addView(sp);
        EditText tests=input("Tests: FBC, RBS, FBS, VDRL, Urinalysis, LFT, U&E, HB, Malaria...");
        body.addView(tests);Button b=btn("SEND TO LAB");body.addView(b);
        b.setOnClickListener(v->{db.getWritableDatabase().execSQL("INSERT INTO lab_orders(patient_id,doctor,tests,status,created_at) VALUES(?,?,?,?,?)",new Object[]{pid(sp),user,tests.getText().toString(),"Pending",DB.now()});db.audit(user,role,"LAB_ORDER",pid(sp)+" "+tests.getText());Toast.makeText(this,"Sent to laboratory",Toast.LENGTH_SHORT).show();});
    }
    void prescription(){
        base("Prescription");Spinner sp=new Spinner(this);patientPick(sp);body.addView(sp);EditText meds=input("Medicines, strength, dose, frequency, duration");body.addView(meds);
        Button b=btn("SUBMIT PRESCRIPTION");body.addView(b);b.setOnClickListener(v->{db.getWritableDatabase().execSQL("INSERT INTO prescriptions(patient_id,doctor,medicines,status,created_at) VALUES(?,?,?,?,?)",new Object[]{pid(sp),user,meds.getText().toString(),"Awaiting accountant",DB.now()});db.audit(user,role,"PRESCRIPTION",pid(sp));Toast.makeText(this,"Prescription submitted",Toast.LENGTH_SHORT).show();});
    }
    void referral(){
        base("Referral");Spinner sp=new Spinner(this);patientPick(sp);body.addView(sp);EditText fac=input("Receiving point of care");EditText reason=input("Reason");body.addView(fac);body.addView(reason);
        Button b=btn("SAVE REFERRAL");body.addView(b);b.setOnClickListener(v->{db.audit(user,role,"REFERRAL",pid(sp)+" -> "+fac.getText()+" "+reason.getText());Toast.makeText(this,"Referral recorded in audit trail",Toast.LENGTH_SHORT).show();});
    }
    void lab(){
        base("Laboratory");
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,patient_id,tests,status FROM lab_orders ORDER BY id DESC",null);
        while(c.moveToNext()){int id=c.getInt(0);String pid=c.getString(1),tests=c.getString(2),st=c.getString(3);TextView t=tv("Order #"+id+" • "+pid+"\n"+tests+"\n"+st,13);body.addView(t);
            EditText r=input("Results for this order");body.addView(r);Button b=btn("UPLOAD RESULT #"+id);body.addView(b);b.setOnClickListener(v->{db.getWritableDatabase().execSQL("INSERT INTO lab_results(order_id,patient_id,results,user,created_at) VALUES(?,?,?,?,?)",new Object[]{id,pid,r.getText().toString(),user,DB.now()});db.getWritableDatabase().execSQL("UPDATE lab_orders SET status='Completed' WHERE id=?",new Object[]{id});db.audit(user,role,"LAB_RESULT",String.valueOf(id));Toast.makeText(this,"Result uploaded",Toast.LENGTH_SHORT).show();});
        }c.close();
    }
    void accountant(){
        base("Pricing & Authorisation");
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,patient_id,medicines,price,status FROM prescriptions WHERE status!='Dispensed'",null);
        while(c.moveToNext()){int id=c.getInt(0);String p=c.getString(1),m=c.getString(2),st=c.getString(4);body.addView(tv("RX #"+id+" • "+p+"\n"+m+"\n"+st,13));EditText price=input("Price MWK");body.addView(price);Button b=btn("AUTHORISE");body.addView(b);b.setOnClickListener(v->{double q=0;try{q=Double.parseDouble(price.getText().toString());}catch(Exception ignored){}db.getWritableDatabase().execSQL("UPDATE prescriptions SET price=?,status='Authorised' WHERE id=?",new Object[]{q,id});db.audit(user,role,"PRESCRIPTION_AUTHORISED","RX "+id+" MWK "+q);Toast.makeText(this,"Authorised",Toast.LENGTH_SHORT).show();});}c.close();
    }
    void receipt(){
        base("Receipt");Spinner sp=new Spinner(this);patientPick(sp);body.addView(sp);EditText amt=input("Amount MWK");EditText det=input("Receipt details");body.addView(amt);body.addView(det);Button b=btn("ISSUE RECEIPT");body.addView(b);
        b.setOnClickListener(v->{double a=0;try{a=Double.parseDouble(amt.getText().toString());}catch(Exception ignored){}db.getWritableDatabase().execSQL("INSERT INTO receipts(patient_id,amount,details,user,created_at) VALUES(?,?,?,?,?)",new Object[]{pid(sp),a,det.getText().toString(),user,DB.now()});db.audit(user,role,"RECEIPT","Patient "+pid(sp)+" MWK "+a);Toast.makeText(this,"Receipt # issued",Toast.LENGTH_SHORT).show();});
    }
    void dispense(){
        base("Pharmacy Dispensing");Cursor c=db.getReadableDatabase().rawQuery("SELECT id,patient_id,medicines,price FROM prescriptions WHERE status='Authorised'",null);
        while(c.moveToNext()){int id=c.getInt(0);String p=c.getString(1),m=c.getString(2);body.addView(tv("RX #"+id+" • "+p+"\n"+m+"\nMWK "+c.getDouble(3),13));Button b=btn("DISPENSE");body.addView(b);b.setOnClickListener(v->{db.getWritableDatabase().execSQL("UPDATE prescriptions SET status='Dispensed' WHERE id=?",new Object[]{id});db.audit(user,role,"DISPENSED","RX "+id+" patient "+p);Toast.makeText(this,"Dispensed and audited",Toast.LENGTH_SHORT).show();});}c.close();
    }
    void stock(){
        base("Bin Card / Stock");EditText item=input("Medicine / commodity");EditText batch=input("Batch number");EditText expiry=input("Expiry YYYY-MM-DD");EditText qty=input("Quantity received / issued");body.addView(item);body.addView(batch);body.addView(expiry);body.addView(qty);
        Button rec=btn("RECEIVE STOCK");Button issue=btn("ISSUE STOCK");body.addView(rec);body.addView(issue);
        rec.setOnClickListener(v->stockTx(item,batch,expiry,qty,"RECEIPT"));issue.setOnClickListener(v->stockTx(item,batch,expiry,qty,"ISSUE"));
        Cursor c=db.getReadableDatabase().rawQuery("SELECT item,batch,expiry,balance FROM stock ORDER BY item",null);while(c.moveToNext())body.addView(tv(c.getString(0)+" | Batch "+c.getString(1)+" | Exp "+c.getString(2)+" | Balance "+c.getDouble(3),12));c.close();
    }
    void stockTx(EditText item,EditText batch,EditText expiry,EditText qty,String type){
        double q=0;try{q=Double.parseDouble(qty.getText().toString());}catch(Exception ignored){}if(q<=0)return;
        Cursor c=db.getReadableDatabase().rawQuery("SELECT balance FROM stock WHERE item=?",new String[]{item.getText().toString()});double bal=0;if(c.moveToFirst())bal=c.getDouble(0);c.close();if(type.equals("ISSUE")&&q>bal){Toast.makeText(this,"Insufficient stock",Toast.LENGTH_SHORT).show();return;}double nb=type.equals("RECEIPT")?bal+q:bal-q;
        db.getWritableDatabase().execSQL("INSERT OR REPLACE INTO stock(item,batch,expiry,balance) VALUES(?,?,?,?)",new Object[]{item.getText().toString(),batch.getText().toString(),expiry.getText().toString(),nb});
        db.getWritableDatabase().execSQL("INSERT INTO stock_tx(item,type,qty,ref,user,created_at) VALUES(?,?,?,?,?,?)",new Object[]{item.getText().toString(),type,q,"BIN-"+System.currentTimeMillis(),user,DB.now()});
        db.audit(user,role,"STOCK_"+type,item.getText()+" qty="+q+" balance="+nb);Toast.makeText(this,"Stock updated. Balance "+nb,Toast.LENGTH_SHORT).show();
    }
    void hts(){
        base("HTS Testing");Spinner sp=new Spinner(this);patientPick(sp);body.addView(sp);String[] labs={"HIV","VDRL","Hepatitis B","Hepatitis C"};EditText[] es=new EditText[4];for(int i=0;i<4;i++){es[i]=input(labs[i]+" result");body.addView(es[i]);}
        Button b=btn("UPLOAD HTS");body.addView(b);b.setOnClickListener(v->{db.getWritableDatabase().execSQL("INSERT INTO hts(patient_id,hiv,vdrl,hepb,hepc,user,created_at) VALUES(?,?,?,?,?,?,?)",new Object[]{pid(sp),es[0].getText(),es[1].getText(),es[2].getText(),es[3].getText(),user,DB.now()});db.audit(user,role,"HTS_RESULT",pid(sp));Toast.makeText(this,"HTS record saved",Toast.LENGTH_SHORT).show();});
    }
    void reports(){
        base("Reports / Export");body.addView(tv("Patients: "+count("patients"),16));body.addView(tv("Lab results: "+count("lab_results"),16));body.addView(tv("Prescriptions: "+count("prescriptions"),16));body.addView(tv("HTS records: "+count("hts"),16));body.addView(tv("Stock transactions: "+count("stock_tx"),16));body.addView(tv("Receipts: "+count("receipts"),16));body.addView(tv("For full CSV/Excel export, add the secure server reporting module in production.",13));
    }
    int count(String t){Cursor c=db.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+t,null);int n=c.moveToFirst()?c.getInt(0):0;c.close();return n;}
    void auditOrTally(String s){
        base(s);
        if(s.startsWith("Accounts")){body.addView(tv("Prescriptions: "+count("prescriptions"),16));body.addView(tv("Dispensing records: "+count("audit"),16));body.addView(tv("Receipts: "+count("receipts"),16));}
        Cursor c=db.getReadableDatabase().rawQuery("SELECT user,role,action,details,created_at FROM audit ORDER BY id DESC LIMIT 100",null);
        while(c.moveToNext())body.addView(tv(c.getString(4)+"\n"+c.getString(0)+" ("+c.getString(1)+") — "+c.getString(2)+"\n"+c.getString(3),12));c.close();
    }
}