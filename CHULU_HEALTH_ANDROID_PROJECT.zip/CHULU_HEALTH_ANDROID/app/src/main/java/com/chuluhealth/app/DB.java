package com.chuluhealth.app;

import android.content.*;
import android.database.sqlite.*;
import android.database.Cursor;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.*;

public class DB extends SQLiteOpenHelper {
    static final String NAME="chulu_health.db"; static final int VER=1;
    DB(Context c){super(c,NAME,null,VER);}
    public void onCreate(SQLiteDatabase d){
        d.execSQL("CREATE TABLE users(username TEXT PRIMARY KEY, password_hash TEXT, role TEXT, active INTEGER)");
        d.execSQL("CREATE TABLE patients(id TEXT PRIMARY KEY, name TEXT, dob TEXT, sex TEXT, phone TEXT, address TEXT, date_registered TEXT)");
        d.execSQL("CREATE TABLE prescriptions(id INTEGER PRIMARY KEY AUTOINCREMENT, patient_id TEXT, doctor TEXT, medicines TEXT, price REAL DEFAULT 0, status TEXT, created_at TEXT)");
        d.execSQL("CREATE TABLE lab_orders(id INTEGER PRIMARY KEY AUTOINCREMENT, patient_id TEXT, doctor TEXT, tests TEXT, status TEXT, created_at TEXT)");
        d.execSQL("CREATE TABLE lab_results(id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER, patient_id TEXT, results TEXT, user TEXT, created_at TEXT)");
        d.execSQL("CREATE TABLE hts(id INTEGER PRIMARY KEY AUTOINCREMENT, patient_id TEXT, hiv TEXT, vdrl TEXT, hepb TEXT, hepc TEXT, user TEXT, created_at TEXT)");
        d.execSQL("CREATE TABLE stock(item TEXT PRIMARY KEY, batch TEXT, expiry TEXT, balance REAL)");
        d.execSQL("CREATE TABLE stock_tx(id INTEGER PRIMARY KEY AUTOINCREMENT, item TEXT, type TEXT, qty REAL, ref TEXT, user TEXT, created_at TEXT)");
        d.execSQL("CREATE TABLE receipts(id INTEGER PRIMARY KEY AUTOINCREMENT, patient_id TEXT, amount REAL, details TEXT, user TEXT, created_at TEXT)");
        d.execSQL("CREATE TABLE audit(id INTEGER PRIMARY KEY AUTOINCREMENT, user TEXT, role TEXT, action TEXT, details TEXT, created_at TEXT)");
        seedUsers(d);
    }
    void seedUsers(SQLiteDatabase d){
        String[][] u={{"ulemu","Doctor","ulemU_PLACEHOLDER"},{"annie","Doctor","annie_PLACEHOLDER"},
        {"carlos","Lab","carlos_PLACEHOLDER"},{"lonjezo","Accountant","lonjezo_PLACEHOLDER"},
        {"mary","Pharmacy","mary_PLACEHOLDER"},{"angella","HTS","angella_PLACEHOLDER"},
        {"emmanual","Data Clerk","emmanuel_PLACEHOLDER"},{"lonjey","Administrator","lonjey_PLACEHOLDER"}};
        // Passwords are set to a demo value in this source. Replace with secure server authentication for production.
        for(String[] x:u)d.execSQL("INSERT INTO users VALUES(?,?,?,1)",new Object[]{x[0],hash("CHULU-DEMO"),x[1]});
    }
    static String hash(String s){try{MessageDigest m=MessageDigest.getInstance("SHA-256");byte[] b=m.digest(s.getBytes("UTF-8"));StringBuilder z=new StringBuilder();for(byte q:b)z.append(String.format("%02x",q));return z.toString();}catch(Exception e){return "";}}
    String login(String user,String pass){
        Cursor c=getReadableDatabase().rawQuery("SELECT role FROM users WHERE username=? AND password_hash=? AND active=1",new String[]{user.toLowerCase(),hash(pass)});
        String r=c.moveToFirst()?c.getString(0):null;c.close();return r;
    }
    String fy(){
        Calendar c=Calendar.getInstance(); int y=c.get(Calendar.YEAR); if(c.get(Calendar.MONTH)<Calendar.APRIL)y--; return String.valueOf(y);
    }
    String patientId(){
        String prefix="CHU-"+fy()+"-";
        Cursor c=getReadableDatabase().rawQuery("SELECT id FROM patients WHERE id LIKE ? ORDER BY id DESC LIMIT 1",new String[]{prefix+"%"});
        int n=1;if(c.moveToFirst()){String s=c.getString(0);try{n=Integer.parseInt(s.substring(s.lastIndexOf("-")+1))+1;}catch(Exception ignored){}}c.close();
        return prefix+String.format("%06d",n);
    }
    void audit(String user,String role,String action,String details){
        getWritableDatabase().execSQL("INSERT INTO audit(user,role,action,details,created_at) VALUES(?,?,?,?,?)",
            new Object[]{user,role,action,details,now()});
    }
    static String now(){return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.getDefault()).format(new Date());}
    public void onUpgrade(SQLiteDatabase d,int a,int b){}
}