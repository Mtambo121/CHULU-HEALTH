# CHULU HEALTH Android

Native Android Java project for the CHULU HEALTH facility workflow.

Included:
- Role-based login/dashboard
- Doctor: patient registration, clinical assessment, lab orders, prescriptions, referrals
- Lab: orders and result upload
- Accountant: prescription pricing and authorisation
- Pharmacy: dispensing and stock/bin card
- HTS: HIV/VDRL/Hep B/Hep C recording
- Data Clerk: basic reporting
- Administrator: audit/tally view
- Automatic patient IDs based on the 1 April–31 March financial year
- Receipt records
- Stock transactions
- Audit trail

IMPORTANT:
This source is a functional offline/local-data foundation, not a production-ready clinical system. It should not be used for real patient information until the server architecture, authentication, encryption, backup, audit controls, privacy compliance and multi-device synchronization are implemented.

Demo password for all seeded users: CHULU-DEMO.
The real passwords supplied in the chat are NOT embedded as plaintext.

Patient ID format:
CHU-YYYY-000001 where YYYY is the financial year beginning 1 April.

Build:
- Open in Android Studio and build the debug APK, or
- Push to GitHub and run the included "Build CHULU HEALTH APK" workflow.
